The issue tracker is the preferred channel for feedback on the project, bugs relating to the publishing infrastructure (which is still a a work-in-progress) or other discussion points. 

Note:

- *Please do not open issues or pull requests that involve including answers to any of the questions.*
- *If you have a proposal for a new question or revision of an existing question, please just open a pull request.*
